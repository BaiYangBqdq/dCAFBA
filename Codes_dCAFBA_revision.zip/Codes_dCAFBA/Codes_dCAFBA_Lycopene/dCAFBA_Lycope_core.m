%% Date 2023-10-31: this code works for simulating lycopene production with iJR904 model.
clear all
% close all
%% load model and data
load Model_iJR904Lyco;
model=changeRxnBounds(model,{'EX_g6p_e_','EX_man6p_e_','EX_succ_e_','EX_mnl_e_','EX_lcts_e_','EX_sucr_e_','EX_malt_e_','EX_fru_e_','EX_sbt_D_e_','EX_man_e_','EX_glcn_e_','EX_arab_L_e_','EX_rib_D_e_','EX_xyl_D_e_','EX_gal_e_','EX_glcn_e_','EX_man6p_e_','EX_glcr_e_','EX_dha_e_','EX_glyc_e_','EX_pyr_e_','EX_akg_e_','EX_cit_e_','EX_fum_e_','EX_mal_L_e_','EX_lac_D_e_','EX_ac_e_','EX_for_e_','EX_etoh_e_'},0,'b');
glc_r=find(strcmp(model.rxns,'EX_glc_e_'));
dxps_r=find(strcmp(model.rxns,'DXPS'));%G3P goes to lycopene synthesis
lyco_r=find(strcmp(model.rxns,'LYCO'));
gapd_r=find(strcmp(model.rxns,'GAPD'));%G3P goes to glycolysis
phiE_r=model.protGroup(2).rxns;
%% parameters
dt = 0.05;       % unit in hour
t = 0:dt:40;     % total time
gamma = 11.02;   % obtain from SI of Erickson'paper in 2017.
lambda_C = 1.17; % strain-specific constant of growth laws;
phi_R0 = 0.049;  % obtain from SI of Erickson'paper in 2017.
phi_Q = 0.45;
phi_C_max = 0.24;
lambda_i = 0.85; % initial growth rate  
phi_R_i = phi_R0+lambda_i./gamma;% growth laws
sigma_i = lambda_i./phi_R_i; 
phi_C_i=1-sigma_i/lambda_C*phi_R_i;
w_E = 4.1*10^-4;
w_C = 1.0*10^-3;%glucose
beta = 1/5.0810;%unit g/mmol   
t_C = 15;
chi_L0_list = [0:0.005:0.15];
% chi_L0 = 0.1;
k_eff = 0.05;%effective competition factor between lyco synthesis and the total E protein
%% save data
sigma_all = nan(length(chi_L0_list),length(t));
chi_R_all = nan(length(chi_L0_list),length(t));
phi_R_all = nan(length(chi_L0_list),length(t));
phi_E_all = nan(length(chi_L0_list),length(t));
chi_C_all = nan(length(chi_L0_list),length(t));
phi_C_all = nan(length(chi_L0_list),length(t));
chi_L_all = nan(length(chi_L0_list),length(t));
phi_L_all = nan(length(chi_L0_list),length(t));
lambda_all = nan(length(chi_L0_list),length(t));
v_R_all = nan(length(chi_L0_list),length(t));
v_C_all = nan(length(chi_L0_list),length(t));
v_E_all = nan(length(chi_L0_list),length(t));
v_G3PConsume_all = nan(length(chi_L0_list),length(t));
v_lyco_all = nan(length(chi_L0_list),length(t));
v_dxps_all = nan(length(chi_L0_list),length(t));
v_gapd_all = nan(length(chi_L0_list),length(t));
Lyco_all = nan(size(chi_L0_list));
%% main loop
tic;
for j = 1:length(chi_L0_list)
    disp(['j=', num2str(j)]);
    chi_L0 = chi_L0_list(j);
    
    sigma=nan(size(t));
    chi_R=nan(size(t));
    phi_R=nan(size(t));
    phi_E=nan(size(t));
    chi_C=nan(size(t));
    phi_C=nan(size(t));
    chi_L=nan(size(t));% regulation function of lycopene
    phi_L=nan(size(t));% protein of lycopene synthesis
    lambda=nan(size(t));
    v_R=nan(size(t));%protein synthesis flux
    v_C=nan(size(t));% uptake flux
    v_E=nan(size(t));
    v_G3PConsume=nan(size(t));
    v_lyco=nan(size(t));
    v_dxps=nan(size(t));
    v_gapd=nan(size(t));
    v=nan(length(model.rxns),length(t));% all rxn fluxes
%% initialization
    sigma(1) = sigma_i;
    lambda(1) = lambda_i;
    phi_C(1) = phi_C_i;
    phi_R(1) = phi_R_i;
    phi_E(1) = 1 - phi_C(1) - phi_R(1) - phi_Q;
    chi_R(1) = phi_R0/(1-sigma(1)/gamma);
    chi_C(1) = (1-sigma(1)/lambda_C*chi_R(1))*phi_C_max;
    chi_L(1) = 0;
    phi_L(1) =0;
    v_R(1) = 4.6;
    v_dxps(1) = 0;
    v_lyco(1) = 0;
    v_gapd(1) = 3;
%     v_G3PConsume(1) = 5;
    v_E(1) = 10;
    for i = 2:length(t)
        if t(i) < t_C
            chi_L(i) = 0;
        end
        if t(i) >= t_C
            chi_L(i) = chi_L0; 
        end
        
        phi_L(i) = sigma(i-1)*phi_R(i-1)*(chi_L(i-1)-phi_L(i-1))*dt+phi_L(i-1);
        v_glc=phi_C(i-1)/w_C; 
        model=changeRxnBounds(model,'EX_glc_e_',-v_glc,'l'); 
        v_lycoCons=k_eff*v_E(i-1)*phi_L(i-1)/phi_E(i-1);
        model=changeRxnBounds(model, {'LYCO'},v_lycoCons,'b');
        [v_R(i),v_C(i),lambda(i),v(:,i),v_E(i),v_lyco(i),v_gapd(i),phi_E(i)] = dCAFBALycope(model,phi_C(i-1),phi_R(i-1),phi_L(i-1),phi_Q,w_E,w_C,glc_r,phiE_r,dxps_r,gapd_r,lyco_r);  
        phi_R(i) = sigma(i-1)*phi_R(i-1)*(chi_R(i-1)-phi_R(i-1))*dt+phi_R(i-1);
        phi_C(i) = sigma(i-1)*phi_R(i-1)*(chi_C(i-1)-phi_C(i-1))*dt+phi_C(i-1);
        sigma(i)=(beta*1/phi_R(i-1)*((v_R(i)-v_R(i-1))/dt-v_R(i-1)*sigma(i-1)*(chi_R(i-1)-phi_R(i-1))))*dt+sigma(i-1);
        chi_R(i) = phi_R0/(1-sigma(i)/gamma);
        chi_C(i) = (1-sigma(i)/lambda_C*chi_R(i))*phi_C_max;
    end
 %% save data
    sigma_all(j,:)=sigma;
    chi_R_all(j,:)=chi_R;
    phi_R_all(j,:)=phi_R;
    phi_E_all(j,:)=phi_E;
    chi_C_all(j,:)=chi_C;
    phi_C_all(j,:)=phi_C;    
    chi_L_all(j,:)=chi_L; 
    phi_L_all(j,:)=phi_L;
    lambda_all(j,:)=lambda;
    v_R_all(j,:)=v_R;
    v_C_all(j,:)=v_C;
    v_E_all(j,:)=v_E; 
    v_lyco_all(j,:)=v_lyco;
    v_dxps_all(j,:)=v_dxps;
    v_gapd_all(j,:)=v_gapd;
    Lyco_all(j)=sum(v_lyco);
   
end
T=toc;  
%% plotting
