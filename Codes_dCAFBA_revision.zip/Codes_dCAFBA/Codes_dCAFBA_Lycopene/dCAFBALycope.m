%% Date 2023-10-25: this code works for simulating lycopenen production with iJR904 model
function [v_R,v_C,lambda,v,v_E,v_lyco,v_gapd,phi_E] = dCAFBALycope(model,phi_C,phi_R,phi_L,phi_Q,w_E,w_C,glc_r,phiE_r,dxps_r,gapd_r,lyco_r)
model.protGroup(4).phi0 = phi_Q+phi_C+phi_R+phi_L;
phi_E=1-model.protGroup(4).phi0;
model=setWeights(model,2,w_E);
sol=CAFBA_OptimizeCbModel_glpk(model); 
v=sol.x;
v_BOF=sol.f;
lambda=v_BOF;
v_C=abs(sol.x(glc_r));
v_dxps=abs(sol.x(dxps_r));
v_gapd=abs(sol.x(gapd_r));
v_lyco=abs(sol.x(lyco_r));
v_R=(0.488+0.281+0.229+0.229+0.087+0.25+0.25+0.582+0.09+0.276+0.428+0.326+0.146+0.176+0.21+0.205+0.241+0.054+0.131+0.402)*v_BOF;
v_E=sum(abs(sol.x(phiE_r)));
end