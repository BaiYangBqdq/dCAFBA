%% date 2022-06-21:this code works for upshift with iJR904.
% function [v_R,v_C1,v_C2,lambda] = dCAFBA2_core(model,phi_C1,phi_C2,phi_Rb,w_E,w_C1,w_C2,h1,h2,pyr_r,glcn_r,phi_Q)
function [v_R,v_C1,v_C2,lambda,v,v_E,phi_E] = uCAFBA2_core(model,phi_C1,phi_C2,phi_Rb,w_E,w_C1,w_C2,h1,h2,succ_r,glcn_r,phi_Q,phiE_r)
model.protGroup(4).phi0 = phi_Q+(phi_C1+phi_C2)+phi_Rb;
phi_E=1-model.protGroup(4).phi0;
model=setWeights(model,2,w_E);
sol=CAFBA_OptimizeCbModel_glpk(model);
v=sol.x;
v_BOF=sol.f;
lambda=v_BOF;
% v_C1=abs(sol.x(pyr_r));
% v_C2=abs(sol.x(glcn_r));
v_C1=abs(sol.x(succ_r));
v_C2=abs(sol.x(glcn_r));
v_R=(0.488+0.281+0.229+0.229+0.087+0.25+0.25+0.582+0.09+0.276+0.428+0.326+0.146+0.176+0.21+0.205+0.241+0.054+0.131+0.402)*v_BOF;
v_E=sum(abs(sol.x(phiE_r)));
v_Gly=sum(abs(sol.x(phiGlyco_r)));
v_TCA=sum(abs(sol.x(phiTCA_r)));
v_AA=sum(abs(sol.x(phiAA_r)));
v_Nuc=sum(abs(sol.x(phiNucle_r)));
end