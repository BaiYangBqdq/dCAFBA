%% Date 2022-06-13: this code works for downshift with iJR904.
%%  glucose+succintae -> succinate
clear all
% close all
%% load model and data
load ModelData_iJR904;
model=changeRxnBounds(model,{'EX_glc_e_','EX_g6p_e_','EX_man6p_e_','EX_succ_e_','EX_mnl_e_','EX_lcts_e_','EX_sucr_e_','EX_malt_e_','EX_fru_e_','EX_sbt_D_e_','EX_man_e_','EX_glcn_e_','EX_arab_L_e_','EX_rib_D_e_','EX_xyl_D_e_','EX_gal_e_','EX_glcn_e_','EX_man6p_e_','EX_glcr_e_','EX_dha_e_','EX_glyc_e_','EX_pyr_e_','EX_akg_e_','EX_cit_e_','EX_fum_e_','EX_mal_L_e_','EX_lac_D_e_','EX_ac_e_','EX_for_e_','EX_etoh_e_'},0,'b');
% pyr_r=find(strcmp(model.rxns,'EX_pyr_e_'));
% glcn_r=find(strcmp(model.rxns,'EX_glcn_e_'));
% model1=addProteinGroupsToModel(model,'pyr+glcn');%C is pyruvate+gluconate
% model2=addProteinGroupsToModel(model,'pyr');

glc_r=find(strcmp(model.rxns,'EX_glc_e_'));
succ_r=find(strcmp(model.rxns,'EX_succ_e_'));
phiE_r=model.protGroup(2).rxns;
model2=addProteinGroupsToModel(model,'succ');%C is succinate
model1=addProteinGroupsToModel(model,'glc+succ');%C is glucose+succinate
%% parameters
dt = 0.05;% unit in hour
t = -20:dt:50;%total time
gamma = 11.02;%obtain from SI of Erickson'paper in 2017.
lambda_C = 1.17;%strain-specific constant of growth laws;
phi_Rb0 = 0.049;%obtain from SI of Erickson'paper in 2017.
lambda_i = 0.92;%experimental data;
lambda_f = 0.45;%experimental data;
phi_Rb_i=phi_Rb0+lambda_i./gamma;%growth laws
phi_Rb_f=phi_Rb0+lambda_f./gamma;
sigma_i = lambda_i./phi_Rb_i; 
sigma_f = lambda_f./phi_Rb_f;
phi_C_i=1-sigma_i/lambda_C*phi_Rb_i;
phi_Q = 0.45;% obtain from You et al., 2013
beta = 1/5.0810;%unit g/mmol;
phi_C_max1 = 0.44;
phi_C_max2 = 0.445;
w_E = 9.18*10^-4;
w_C1 = 1.96*10^-2;%succinate
w_C2 = 4.3*10^-3;%glucose
h1=0.62;
h2=1;
%% save data
sigma=nan(size(t));
chi_Rb=nan(size(t));
chi_C=nan(size(t));
phi_C1=nan(size(t));
phi_C2=nan(size(t));
phi_Rb=nan(size(t));
phi_E=nan(size(t));
lambda=nan(size(t));
v_R=nan(size(t));%protein synthesis flux
v_C1=nan(size(t));%C1 uptake flux
v_C2=nan(size(t));%C2 uptake flux
v=nan(length(model.rxns),length(t));% all rxn fluxes
%% initialization
sigma(1) = sigma_i;
lambda(1) = lambda_i;
phi_C1(1) = 0.051;
phi_C2(1) = 0.045;
phi_Rb(1) = phi_Rb_i;
phi_E(1) = 0.3215;
chi_Rb(1) = phi_Rb_i;
chi_C(1) = phi_C_i;
v_R(1) = 4.6;
%% main loop
t0=find(t==0);
for i=2:length(t)
    if t(i) < 0
%         v_pyr=phi_C1(i-1)/w_C1;
%         v_glcn=phi_C2(i-1)/w_C2;
%         model1=changeRxnBounds(model1,'EX_pyr_e_',-v_pyr,'l');
%         model1=changeRxnBounds(model1,'EX_glcn_e_',-v_glcn,'l');
%         [v_R(i),v_C1(i),v_C2(i),lambda(i)] = dCAFBA1_core(model1,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,pyr_r,glcn_r,phi_Q);

        v_succ=phi_C1(i-1)/w_C1;
        v_glc=phi_C2(i-1)/w_C2;
        model1=changeRxnBounds(model1,'EX_succ_e_',-v_succ,'l');
        model1=changeRxnBounds(model1,'EX_glc_e_',-v_glc,'l');
%         model1=changeRxnBounds(model1,'EX_glc_e_',-v_glc,'l');
        [v_R(i),v_C1(i),v_C2(i),lambda(i),v(:,i),v_E(i),phi_E(i)] = dCAFBA1_core(model1,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,succ_r,glc_r,phi_Q,phiE_r);
        phi_Rb(i)=sigma(i-1)*phi_Rb(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))*dt+phi_Rb(i-1);
        phi_C1(i)=sigma(i-1)*phi_Rb(i-1)*(h1*chi_C(i-1)-phi_C1(i-1))*dt+phi_C1(i-1);
        phi_C2(i)=sigma(i-1)*phi_Rb(i-1)*((1-h1)*chi_C(i-1)-phi_C2(i-1))*dt+phi_C2(i-1);   
        sigma(i)=(beta*1/phi_Rb(i-1)*((v_R(i)-v_R(i-1))/dt-v_R(i-1)*sigma(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))))*dt+sigma(i-1);
        chi_Rb(i)=phi_Rb0/(1-sigma(i)/gamma);
        chi_C(i)=(1-sigma(i)/lambda_C*chi_Rb(i))*phi_C_max1;
     
    elseif t(i)==0

%         v_pyr=phi_C1(i-1)/w_C1;
%         model2=changeRxnBounds(model2,'EX_pyr_e_',-v_pyr,'l');
%         [v_R(i),v_C1(i),v_C2(i),lambda(i)] = dCAFBA2_core(model2,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,pyr_r,glcn_r,phi_Q);
        v_succ=phi_C1(i-1)/w_C1;
        model2=changeRxnBounds(model2,'EX_succ_e_',-v_succ,'l');
        [v_R(i),v_C1(i),v_C2(i),lambda(i),v(:,i),v_E(i),phi_E(i)] = dCAFBA2_core(model2,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,succ_r,glc_r,phi_Q,phiE_r);
        sigma(i)=beta*v_R(i)/phi_Rb(i-1);
        chi_Rb(i)=phi_Rb0/(1-sigma(i)/gamma);
        chi_C(i)=(1-sigma(i)/lambda_C*chi_Rb(i))*phi_C_max2;
        phi_Rb(i)=sigma(i)*phi_Rb(i-1)*(chi_Rb(i)-phi_Rb(i-1))*dt+phi_Rb(i-1);
        phi_C1(i)=sigma(i)*phi_Rb(i-1)*(h2*chi_C(i)-phi_C1(i-1))*dt+phi_C1(i-1);
        phi_C2(i)=sigma(i)*phi_Rb(i-1)*((1-h2)*chi_C(i)-phi_C2(i-1))*dt+phi_C2(i-1);  

    else
        
%         v_pyr=phi_C1(i-1)/w_C1;
%         model2=changeRxnBounds(model2,'EX_pyr_e_',-v_pyr,'l');
%         [v_R(i),v_C1(i),v_C2(i),lambda(i)] = dCAFBA2_core(model2,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,pyr_r,glcn_r,phi_Q);
        v_succ=phi_C1(i-1)/w_C1;
        model2=changeRxnBounds(model2,'EX_succ_e_',-v_succ,'l');
%         model2=changeRxnBounds(model2,'EX_succ_e_',-v_succ,'l'); 
        [v_R(i),v_C1(i),v_C2(i),lambda(i),v(:,i),v_E(i),phi_E(i)] = dCAFBA2_core(model2,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,succ_r,glc_r,phi_Q,phiE_r);
        phi_Rb(i)=sigma(i-1)*phi_Rb(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))*dt+phi_Rb(i-1);
        phi_C1(i)=sigma(i-1)*phi_Rb(i-1)*(h2*chi_C(i-1)-phi_C1(i-1))*dt+phi_C1(i-1);
        phi_C2(i)=sigma(i-1)*phi_Rb(i-1)*((1-h2)*chi_C(i-1)-phi_C2(i-1))*dt+phi_C2(i-1);
        sigma(i)=(beta*1/phi_Rb(i-1)*((v_R(i)-v_R(i-1))/dt-v_R(i-1)*sigma(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))))*dt+sigma(i-1);
        chi_Rb(i)=phi_Rb0/(1-sigma(i)/gamma);
        chi_C(i)=(1-sigma(i)/lambda_C*chi_Rb(i))*phi_C_max2;
    end 
end

%% plotting
