%Date:202207: Upshift: from succ to succ and glcn 
clear all
% close all
%% parameters
dt = 0.05;              % unit in hour
tlist = -20:dt:15;      % total time

gamma = 11.02;          % obtain from SI of Erickson'paper in 2017.
lambda_C = 1.17;        % strain-specific constant of growth laws;
phi_R0 = 0.049;         % obtain from SI of Erickson'paper in 2017.
phi_Q = 0.45;
phi_C_max = 1-phi_R0-phi_Q-0.1;

lambda_i = 0.45;        % 
lambda_f = 0.94;        % 
phi_R_i = phi_R0+lambda_i./gamma;% growth laws
phi_R_f = phi_R0+lambda_f./gamma;
sigma_i = lambda_i./phi_R_i; 
sigma_f = lambda_f./phi_R_f;
phi_C_i = (1-sigma_i*phi_R_i/lambda_C)*phi_C_max;
phi_C_f = (1-sigma_f*phi_R_f/lambda_C)*phi_C_max;
mu_i = lambda_i/((1-lambda_i/lambda_C)*phi_C_max);            % carbon-intake dependent protein synthesis flux;
mu_f = lambda_f/((1-lambda_f/lambda_C)*phi_C_max);            % carbon-intake dependent protein synthesis flux;

h1=0.45;                % co-utilization factor

beta = sigma_f*phi_R_f/(1-phi_C_f-phi_R_f-phi_Q);
%% FCR
sigma=nan(size(tlist));
chi_R=nan(size(tlist));
phi_R=nan(size(tlist));
phi_E=nan(size(tlist));
lambda=nan(size(tlist));
chi_C=zeros(size(tlist));
chi_C1=zeros(size(tlist));
chi_C2=nan(size(tlist));
phi_C=nan(size(tlist));
phi_C1=nan(size(tlist));
phi_C2=nan(size(tlist));


sigma(1) = sigma_i;
lambda(1) = lambda_i;
phi_C(1) = phi_C_i;
phi_C1(1) = phi_C(1);
phi_C2(1) = 0;
phi_R(1) = phi_R_i;
phi_E(1) = 1 - phi_C(1) - phi_R(1) - phi_Q;
chi_R(1) = phi_R0/(1-sigma(1)/gamma);
chi_C(1) = 1-sigma(1)/lambda_C*chi_R(1);
chi_C1(1) = h1*chi_C(1);
chi_C2(1) = (1-h1)*chi_C(1);

t0=find(tlist==0);
for i = 2:length(tlist)
    if tlist(i)<=0
        sigma(i) = sigma_i;
        chi_R(i) = phi_R_i;
        chi_C(i) = phi_C_i;
        chi_C1(i) = chi_C(i);
        chi_C2(i) = 0;
        phi_R(i) = phi_R_i;
        phi_C1(i) = phi_C_i;
        phi_C2(i) = 0;
        
    end

        
    if tlist(i)>0
        sigma(t0)=sigma_i;
        sigma(i) = sigma(i-1)*(mu_f*chi_C(i-1)-sigma(i-1)*chi_R(i-1))*dt+sigma(i-1);
        chi_R(i) = phi_R0/(1-sigma(i)/gamma);
        chi_C(i) = (1-sigma(i)/lambda_C*chi_R(i))*phi_C_max;
        chi_C1(i) = h1*chi_C(i);
        chi_C2(i) = (1-h1)*chi_C(i);
        phi_R(i) = sigma(i-1)*phi_R(i-1)*(chi_R(i-1)-phi_R(i-1))*dt+phi_R(i-1);
        phi_C1(i) = sigma(i-1)*phi_R(i-1)*(chi_C1(i-1)-phi_C1(i-1))*dt+phi_C1(i-1);
        phi_C2(i) = sigma(i-1)*phi_R(i-1)*(chi_C2(i-1)-phi_C2(i-1))*dt+phi_C2(i-1);
        
    end
   
    phi_C(i) = phi_C1(i)+phi_C2(i);
    phi_E(i) = 1-phi_C(i)-phi_R(i)-phi_Q;
    lambda(i) = sigma(i)*phi_R(i);
end

%% modified FCR for upshift
mFCR_sigma=nan(size(tlist));
mFCR_chi_R=nan(size(tlist));
mFCR_phi_R=nan(size(tlist));
mFCR_phi_E=nan(size(tlist));
mFCR_lambda=nan(size(tlist));
mFCR_chi_C=zeros(size(tlist));
mFCR_chi_C1=zeros(size(tlist));
mFCR_chi_C2=nan(size(tlist));
mFCR_phi_C=nan(size(tlist));
mFCR_phi_C1=nan(size(tlist));
mFCR_phi_C2=nan(size(tlist));


mFCR_sigma(1) = sigma_i;
mFCR_lambda(1) = lambda_i;
mFCR_phi_C(1) = phi_C_i;
mFCR_phi_C1(1) = mFCR_phi_C(1)*h1;
mFCR_phi_C2(1) = mFCR_phi_C(1)*(1-h1);
mFCR_phi_R(1) = phi_R_i;
mFCR_phi_E(1) = 1 - mFCR_phi_C(1) - mFCR_phi_R(1) - phi_Q;
mFCR_chi_R(1) = phi_R0/(1-mFCR_sigma(1)/gamma);
mFCR_chi_C(1) = 1-mFCR_sigma(1)/lambda_C*mFCR_chi_R(1);
mFCR_chi_C1(1) = h1*mFCR_chi_C(1);
mFCR_chi_C2(1) = (1-h1)*mFCR_chi_C(1);

for i = 2:length(tlist)
    if tlist(i)<=0     
        mFCR_sigma(i) = sigma_i;
        mFCR_chi_R(i) = phi_R_i;
        mFCR_chi_C(i) = phi_C_i;
        mFCR_chi_C1(i) = mFCR_chi_C(i);
        mFCR_chi_C2(i) = 0;
        mFCR_phi_R(i) = phi_R_i;
        mFCR_phi_C1(i) = phi_C_i;
        mFCR_phi_C2(i) = 0;
    end
        
    if tlist(i)>0
        mFCR_sigma(t0)=sigma_i;
        if mu_f*mFCR_phi_C2(i-1)<=beta*mFCR_phi_E(i-1)
            mFCR_sigma(i) = mFCR_sigma(i-1)*(mu_f*mFCR_chi_C(i-1)-mFCR_sigma(i-1)*mFCR_chi_R(i-1))*dt + mFCR_sigma(i-1);
        else
            mFCR_sigma(i) = mFCR_sigma(i-1)*(beta*(1-phi_Q) ...
                -(beta*mFCR_chi_C(i-1)+beta*mFCR_chi_R(i-1)+mFCR_sigma(i-1)*mFCR_phi_R(i-1)))*dt + mFCR_sigma(i-1);
        end
        mFCR_chi_R(i) = phi_R0/(1-mFCR_sigma(i)/gamma);
        mFCR_chi_C(i) = (1-mFCR_sigma(i)/lambda_C*mFCR_chi_R(i))*phi_C_max;
        mFCR_chi_C1(i) = h1*mFCR_chi_C(i);
        mFCR_chi_C2(i) = (1-h1)*mFCR_chi_C(i);
        mFCR_phi_R(i) = mFCR_sigma(i-1)*mFCR_phi_R(i-1)*(mFCR_chi_R(i-1)-mFCR_phi_R(i-1))*dt+mFCR_phi_R(i-1);
        mFCR_phi_C1(i) = mFCR_sigma(i-1)*mFCR_phi_R(i-1)*(mFCR_chi_C1(i-1)-mFCR_phi_C1(i-1))*dt+mFCR_phi_C1(i-1);
        mFCR_phi_C2(i) = mFCR_sigma(i-1)*mFCR_phi_R(i-1)*(mFCR_chi_C2(i-1)-mFCR_phi_C2(i-1))*dt+mFCR_phi_C2(i-1);

    end   
   
    mFCR_phi_C(i) = mFCR_phi_C1(i)+mFCR_phi_C2(i);
    mFCR_phi_E(i) = 1-mFCR_phi_C(i)-mFCR_phi_R(i)-phi_Q;
    mFCR_lambda(i) = mFCR_sigma(i)*mFCR_phi_R(i);
end

%% plotting
