%% Date 2023-10-25: this code works for downshift with the iML1515 model
%%  glucose+succintae -> succinate
clear all
% close all
%% load model
load Model_iML1515;
iML1515_Succ=changeRxnBounds(iML1515_Succ,{'EX_glc__D_e','EX_g6p_e','EX_man6p_e','EX_succ_e','EX_mnl_e','EX_lcts_e','EX_sucr_e','EX_malt_e','EX_fru_e','EX_sbt__D_e','EX_man_e','EX_glcn_e','EX_arab__L_e','EX_rib__D_e','EX_xyl__D_e','EX_gal_e','EX_glcn_e','EX_man6p_e','EX_glcr_e','EX_dha_e','EX_glyc_e','EX_pyr_e','EX_akg_e','EX_cit_e','EX_fum_e','EX_mal__L_e','EX_lac__D_e','EX_ac_e','EX_for_e','EX_etoh_e'},0,'b');
iML1515_GlcSucc=changeRxnBounds(iML1515_GlcSucc,{'EX_glc__D_e','EX_g6p_e','EX_man6p_e','EX_succ_e','EX_mnl_e','EX_lcts_e','EX_sucr_e','EX_malt_e','EX_fru_e','EX_sbt__D_e','EX_man_e','EX_glcn_e','EX_arab__L_e','EX_rib__D_e','EX_xyl__D_e','EX_gal_e','EX_glcn_e','EX_man6p_e','EX_glcr_e','EX_dha_e','EX_glyc_e','EX_pyr_e','EX_akg_e','EX_cit_e','EX_fum_e','EX_mal__L_e','EX_lac__D_e','EX_ac_e','EX_for_e','EX_etoh_e'},0,'b');
glc_r=find(strcmp(iML1515_Succ.rxns,'EX_glc__D_e'));
succ_r=find(strcmp(iML1515_Succ.rxns,'EX_succ_e'));
phiE_r=iML1515_Succ.protGroup(2).rxns;
model2=iML1515_Succ;%C is succinate
model1=iML1515_GlcSucc;%C is glucose+succinate
%% parameters
dt = 0.05;% unit in hour
t = -10:dt:20;%total time
gamma = 11.02;%obtain from SI of Erickson'paper in 2017.
lambda_C = 1.17;%strain-specific constant of growth laws;
phi_Rb0 = 0.049;%obtain from SI of Erickson'paper in 2017.
lambda_i = 0.92;%experimental data
lambda_f = 0.45;%experimental data
phi_Rb_i=phi_Rb0+lambda_i./gamma;%growth laws
phi_Rb_f=phi_Rb0+lambda_f./gamma;
sigma_i = lambda_i./phi_Rb_i; 
sigma_f = lambda_f./phi_Rb_f;
phi_C_i=1-sigma_i/lambda_C*phi_Rb_i;
phi_Q = 0.45;% obtain from You et al., 2013;
beta = 1/5.3485;%unit g/mmol;
phi_C_max1 = 0.44;
phi_C_max2 = 0.42;
w_E = 5.15*10^-4;% from Mori et al.,2016
w_C1 = 1.6*10^-2;%succinate
w_C2 = 2.9*10^-3;%glucose
h1=0.6;
h2=1;
%% save data
sigma=nan(size(t));
chi_Rb=nan(size(t));
chi_C=nan(size(t));
phi_C1=nan(size(t));
phi_C2=nan(size(t));
phi_Rb=nan(size(t));
phi_E=nan(size(t));
lambda=nan(size(t));
v_R=nan(size(t));%protein synthesis flux
v_C1=nan(size(t));%C1 uptake flux
v_C2=nan(size(t));%C2 uptake flux
v=nan(length(model.rxns),length(t));% all rxn fluxes
%% initialization
sigma(1) = sigma_i;
lambda(1) = lambda_i;
phi_C1(1) = 0.051;
phi_C2(1) = 0.045;
phi_Rb(1) = phi_Rb_i;
phi_E(1) = 0.3215;
chi_Rb(1) = phi_Rb_i;
chi_C(1) = phi_C_i;
v_R(1) = 4.6;
%% main loop
tic;
t0=find(t==0);
for i=2:length(t)
    if t(i) < 0
        v_succ=phi_C1(i-1)/w_C1;
        v_glc=phi_C2(i-1)/w_C2;
        model1=changeRxnBounds(model1,'EX_succ_e',-v_succ,'l');
        model1=changeRxnBounds(model1,'EX_glc__D_e',-v_glc,'l');
        [v_R(i),v_C1(i),v_C2(i),lambda(i),v(:,i),v_E(i),phi_E(i)] = dCAFBA1_core(model1,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,succ_r,glc_r,phi_Q,phiE_r);
        phi_Rb(i)=sigma(i-1)*phi_Rb(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))*dt+phi_Rb(i-1);
        phi_C1(i)=sigma(i-1)*phi_Rb(i-1)*(h1*chi_C(i-1)-phi_C1(i-1))*dt+phi_C1(i-1);
        phi_C2(i)=sigma(i-1)*phi_Rb(i-1)*((1-h1)*chi_C(i-1)-phi_C2(i-1))*dt+phi_C2(i-1);   
        sigma(i)=(beta*1/phi_Rb(i-1)*((v_R(i)-v_R(i-1))/dt-v_R(i-1)*sigma(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))))*dt+sigma(i-1);
        chi_Rb(i)=phi_Rb0/(1-sigma(i)/gamma);
        chi_C(i)=(1-sigma(i)/lambda_C*chi_Rb(i))*phi_C_max1;
     
    elseif t(i)==0

        v_succ=phi_C1(i-1)/w_C1;
        model2=changeRxnBounds(model2,'EX_succ_e',-v_succ,'l');
        [v_R(i),v_C1(i),v_C2(i),lambda(i),v(:,i),v_E(i),phi_E(i)] = dCAFBA2_core(model2,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,succ_r,glc_r,phi_Q,phiE_r);
        sigma(i)=beta*v_R(i)/phi_Rb(i-1);
        chi_Rb(i)=phi_Rb0/(1-sigma(i)/gamma);
        chi_C(i)=(1-sigma(i)/lambda_C*chi_Rb(i))*phi_C_max2;
        phi_Rb(i)=sigma(i)*phi_Rb(i-1)*(chi_Rb(i)-phi_Rb(i-1))*dt+phi_Rb(i-1);
        phi_C1(i)=sigma(i)*phi_Rb(i-1)*(h2*chi_C(i)-phi_C1(i-1))*dt+phi_C1(i-1);
        phi_C2(i)=sigma(i)*phi_Rb(i-1)*((1-h2)*chi_C(i)-phi_C2(i-1))*dt+phi_C2(i-1);  

    else
        
        v_succ=phi_C1(i-1)/w_C1;
        model2=changeRxnBounds(model2,'EX_succ_e',-v_succ,'l');
        [v_R(i),v_C1(i),v_C2(i),lambda(i),v(:,i),v_E(i),phi_E(i)] = dCAFBA2_core(model2,phi_C1(i-1),phi_C2(i-1),phi_Rb(i-1),w_E,w_C1,w_C2,h1,h2,succ_r,glc_r,phi_Q,phiE_r);
        phi_Rb(i)=sigma(i-1)*phi_Rb(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))*dt+phi_Rb(i-1);
        phi_C1(i)=sigma(i-1)*phi_Rb(i-1)*(h2*chi_C(i-1)-phi_C1(i-1))*dt+phi_C1(i-1);
        phi_C2(i)=sigma(i-1)*phi_Rb(i-1)*((1-h2)*chi_C(i-1)-phi_C2(i-1))*dt+phi_C2(i-1);
        sigma(i)=(beta*1/phi_Rb(i-1)*((v_R(i)-v_R(i-1))/dt-v_R(i-1)*sigma(i-1)*(chi_Rb(i-1)-phi_Rb(i-1))))*dt+sigma(i-1);
        chi_Rb(i)=phi_Rb0/(1-sigma(i)/gamma);
        chi_C(i)=(1-sigma(i)/lambda_C*chi_Rb(i))*phi_C_max2;
    end 
end
TT=toc;
%% plotting
