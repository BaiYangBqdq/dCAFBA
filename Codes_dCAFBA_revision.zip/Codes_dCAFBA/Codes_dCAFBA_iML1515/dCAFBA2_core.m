%% 2023-10-25: this code works for downshift with the iML1515 model
function [v_R,v_C1,v_C2,lambda,v,v_E,phi_E] = dCAFBA2_core(model,phi_C1,phi_C2,phi_Rb,w_E,w_C1,w_C2,h1,h2,succ_r,glc_r,phi_Q,phiE_r)
model.protGroup(4).phi0 = phi_Q+(phi_C1+phi_C2)+phi_Rb;
phi_E=1-model.protGroup(4).phi0;
model=setWeights(model,2,w_E);
sol=CAFBA_OptimizeCbModel_glpk(model);
v=sol.x;
v_BOF=sol.f;
lambda=v_BOF;
v_C1=abs(sol.x(succ_r));
v_C2=abs(sol.x(glc_r));
v_R=(0.513689+0.295792+0.241055+0.241055+0.09158+0.26316+0.26316+0.612638+0.094738+0.290529+0.450531+0.343161+0.153686+0.185265+0.221055+0.215792+0.253687+0.056843+0.137896+0.423162)*v_BOF;
v_E=sum(abs(sol.x(phiE_r)));
end